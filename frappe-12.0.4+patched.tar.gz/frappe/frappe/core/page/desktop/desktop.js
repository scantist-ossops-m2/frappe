frappe.pages['desktop'].on_page_load = function() {
	frappe.utils.set_title(__("Home"));
};
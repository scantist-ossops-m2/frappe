// Copyright (c) 2019, Frappe Technologies and contributors
// For license information, please see license.txt
/* eslint-disable */

frappe.query_reports["Transaction Log Report"] = {
	onload: function(query_report) {
		 query_report.add_make_chart_button = function() {
			//
		};
	}
}

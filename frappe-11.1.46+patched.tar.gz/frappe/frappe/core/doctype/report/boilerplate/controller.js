// Copyright (c) 2016, {app_publisher} and contributors
// For license information, please see license.txt
/* eslint-disable */

frappe.query_reports["{name}"] = {{
	"filters": [

	]
}}
